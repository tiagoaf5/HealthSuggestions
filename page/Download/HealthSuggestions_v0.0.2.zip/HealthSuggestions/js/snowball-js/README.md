https://github.com/fortnightlabs/snowball-js
